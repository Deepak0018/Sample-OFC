package com.portal.library_management.dao;

import java.sql.Connection;

public class TestDBConnection {
	

/** 
 * @param args
 */
public static void main(String[] args) {
		
		Connection c = DBConnectionManager.getConnection();
		
		if(c != null) {
			System.out.println("Connection Successful");
		}
		
	}
}

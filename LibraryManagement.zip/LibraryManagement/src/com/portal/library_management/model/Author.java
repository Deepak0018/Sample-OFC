package com.portal.library_management.model;

public class Author {
	
	private String name;
	private String email;
	public String book_isbn;
	
	public Author(String name, String email, String book_isbn) {
		this.name = name;
		this.email = email;
		this.book_isbn = book_isbn;
	}

	
	/** 
	 * @return String
	 */
	public String getName() {
		return name;
	}

	
	/** 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	
	/** 
	 * @return String
	 */
	public String getEmail() {
		return email;
	}

	
	/** 
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	
	/** 
	 * @return String
	 */
	public String getBook_isbn() {
		return book_isbn;
	}

	
	/** 
	 * @param book_isbn
	 */
	public void setBook_isbn(String book_isbn) {
		this.book_isbn = book_isbn;
	}

	
	/** 
	 * @return String
	 */
	@Override
	public String toString() {
		return "" + name + "\t" + email + "\t" + book_isbn;
	}

}

package com.portal.library_management.model;

public class Student {
	
	public String usn;
	public String name;
	
	public Student(String usn, String name) {
		this.usn = usn;
		this.name = name;
	}

	
	/** 
	 * @return String
	 */
	public String getUsn() {
		return usn;
	}

	
	/** 
	 * @param usn
	 */
	public void setUsn(String usn) {
		this.usn = usn;
	}

	
	/** 
	 * @return String
	 */
	public String getName() {
		return name;
	}

	
	/** 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	
	/** 
	 * @return String
	 */
	@Override
	public String toString() {
		return "Student [usn=" + usn + ", name=" + name + "]";
	}

}
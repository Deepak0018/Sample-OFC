package com.portal.library_management.model;

public class Admin {
    String id;
    String password;

    public Admin(String id, String password){
        this.id = id;
        this.password = password;
    }

    
    /** 
     * @return String
     */
    public String getId() {
        return id;
    }

    
    /** 
     * @return String
     */
    public String getPassword() {
        return password;
    }
}
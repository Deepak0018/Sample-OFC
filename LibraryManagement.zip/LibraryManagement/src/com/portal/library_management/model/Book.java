package com.portal.library_management.model;

public class Book {
    private String isbn;
	private String title;
	private String Category;
	private int quantity;
	
	public Book(String isbn, String title, String category, int quantity) {
		this.isbn = isbn;
		this.title = title;
		Category = category;
		this.quantity = quantity;
	}

	
	/** 
	 * @return String
	 */
	public String getIsbn() {
		return isbn;
	}

	
	/** 
	 * @param isbn
	 */
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	
	/** 
	 * @return String
	 */
	public String getTitle() {
		return title;
	}

	
	/** 
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	
	/** 
	 * @return String
	 */
	public String getCategory() {
		return Category;
	}

	
	/** 
	 * @param category
	 */
	public void setCategory(String category) {
		Category = category;
	}

	
	/** 
	 * @return int
	 */
	public int getQuantity() {
		return quantity;
	}

	
	/** 
	 * @param quantity
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	
	/** 
	 * @return String
	 */
	@Override
	public String toString() {
		return "" + isbn + "\t\t" + title + "\t\t" + Category + "\t\t" + quantity;
	}
	
}

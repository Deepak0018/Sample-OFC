cd ../../build/classes
java -cp ../../dist/lib/*; com.portal.library_management.view.LoginFrame
cd ../../scripts/windows
#!/bin/sh

cd ../../

javac -cp dist/lib/mysql-connector-java-5.0.8-bin; -d build/classes src/com/portal/library_management/model/*.java src/com/portal/library_management/dao/*.java src/com/portal/library_management/view/*.java

cd scripts/linux